import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JobListComponent } from "./job/job-list/job-list.component";
import { JobEditComponent} from "./job/job-edit/job-edit.component";
import {JobCreateComponent} from "./job/job-create/job-create.component";
import {JobViewComponent} from "./job/job-view/job-view.component";
import {ManCreateComponent} from "./man/man-create/man-create.component";
import {ManEditComponent} from "./man/man-edit/man-edit.component";
import {ManViewComponent} from "./man/man-view/man-view.component";

/**
 * All available routes.
 */
const routes: Routes = [
  {
    component: JobListComponent,
    path: "jobs"
  },
  {
    component: JobEditComponent,
    path: "jobs/:jobUuid/edit"
  },
  {
    component: JobCreateComponent,
    path: "jobs/create"
  },
  {
    component: JobViewComponent,
    path: "jobs/:jobUuid/details"
  },
  {
    component: ManCreateComponent,
    path: "jobs/:jobUuid/men/create"
  },
  {
    component: ManEditComponent,
    path: "jobs/:jobUuid/men/:manUuid/edit"
  },
  {
    component: ManViewComponent,
    path: "jobs/:jobUuid/men/:manUuid/details"
  }
];

/**
 * Global routing module.
 */
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {

}

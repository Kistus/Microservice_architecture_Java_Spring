import { Man } from "./man";

/**
 * List of professions.
 */
export interface Men {

  /**
   * List of all professions.
   */
  men: Man[];

}

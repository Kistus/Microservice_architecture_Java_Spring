import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FooterComponent } from './component/footer/footer.component';
import { HeaderComponent } from './component/header/header.component';
import { NavComponent } from './component/nav/nav.component';
import { MainComponent } from './component/main/main.component';
import { JobListComponent } from './job/job-list/job-list.component';
import { HttpClientModule } from "@angular/common/http";
import { JobService } from "./job/service/job.service";
import { FormsModule } from "@angular/forms";
import {AppRoutingModule} from "./app-routing.module";
import {JobEditComponent} from "./job/job-edit/job-edit.component";
import {JobCreateComponent} from "./job/job-create/job-create.component";
import {JobViewComponent} from "./job/job-view/job-view.component";
import {ManService} from "./man/service/man.service";
import {ManCreateComponent} from "./man/man-create/man-create.component";
import {ManEditComponent} from "./man/man-edit/man-edit.component";

/**
 * Application main module.
 */
@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    NavComponent,
    MainComponent,
    JobListComponent,
    JobEditComponent,
    JobCreateComponent,
    JobViewComponent,
    ManCreateComponent,
    ManEditComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [
    JobService,
    ManService
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule {

}
